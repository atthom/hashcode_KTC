from utils import *


def parser():
    pass


def solver():
    pass


def answer():
    print("1 0\r2 2 1")


if __name__ == '__main__':
    answer()
